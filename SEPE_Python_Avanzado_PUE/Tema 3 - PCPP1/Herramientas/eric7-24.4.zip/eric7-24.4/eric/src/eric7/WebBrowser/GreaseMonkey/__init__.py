# -*- coding: utf-8 -*-

# Copyright (c) 2012 - 2024 Detlev Offenbach <detlev@die-offenbachs.de>
#

"""
Package implementing the GreaseMonkey support.
"""

#
# The code in this package was inspired and ported in parts from QupZilla
# Copyright (C) David Rosca <nowrep@gmail.com>
#
