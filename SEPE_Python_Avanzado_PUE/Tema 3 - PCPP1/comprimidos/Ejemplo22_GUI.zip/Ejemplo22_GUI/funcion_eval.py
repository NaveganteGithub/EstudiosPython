variable_global ="1+1"
resultado  = str(eval(variable_global))
print(resultado)

variable_global ="2-1"
resultado  = str(eval(variable_global))
print(resultado)


variable_global ="2*4"
resultado  = str(eval(variable_global))
print(resultado)

variable_global ="4/2"
resultado  = str(eval(variable_global))
print(resultado)