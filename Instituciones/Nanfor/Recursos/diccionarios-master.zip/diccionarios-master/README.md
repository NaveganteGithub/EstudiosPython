# Diccionarios de: usuarios, passwords, xss, dorks, etc..

<img style="float:left" alt="netspy logo" src="https://github.com/hackingyseguridad/diccionarios/blob/master/25pass.png">

# diccionario.txt Usuarios y contraseñas mas usadas, el 99% en lengua castellana 

Descargar:

wget https://raw.githubusercontent.com/hackingyseguridad/diccionarios/master/diccionario.txt

# usuarios.txt  1000 usuarios o claves, mas cumunes

Descargar:

wget https://raw.githubusercontent.com/hackingyseguridad/diccionarios/master/usuarios.txt

# xss.txt Para pruebas XSS sobre WEB

Descargar:

wget https://raw.githubusercontent.com/hackingyseguridad/diccionarios/master/xss.txt

# dorks.txt. Para busqueda en google de vulnerabilidades web y SQLi

Descargar:

wget https://raw.githubusercontent.com/hackingyseguridad/diccionarios/master/dorks.txt
#
#
www.hackingyseguridad.com

http://www.softg.nl/passwords.html
